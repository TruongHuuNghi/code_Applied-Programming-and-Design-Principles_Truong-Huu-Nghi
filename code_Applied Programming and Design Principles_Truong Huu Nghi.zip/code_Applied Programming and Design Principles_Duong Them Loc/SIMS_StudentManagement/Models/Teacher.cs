﻿namespace SIMS_StudentManagement.Models
{
    public class Teacher
    {
        public int ID { get; set; }
        public string TeacherCode { get; set; }
        public string TeacherName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Major { get; set; }
        public string Qualification { get; set; }
    }
}
