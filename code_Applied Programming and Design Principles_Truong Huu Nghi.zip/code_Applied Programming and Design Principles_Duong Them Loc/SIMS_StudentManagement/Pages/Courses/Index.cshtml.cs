using Microsoft.AspNetCore.Mvc.RazorPages;
using SIMS_StudentManagement.Models;
using SIMS_StudentManagement.Services;
using System.Collections.Generic;
using System.Linq;

namespace SIMS_StudentManagement.Pages.Courses
{
    public class IndexModel : PageModel
    {
        private readonly CourseService _courseService;

        public IndexModel(CourseService courseService)
        {
            _courseService = courseService;
        }

        public List<Course> Courses { get; set; }

        public void OnGet(string searchTerm)
        {
            Courses = string.IsNullOrEmpty(searchTerm)
                ? _courseService.GetAllCourses()
                : _courseService.GetAllCourses().Where(c => c.CourseName.Contains(searchTerm) || c.CourseCode.Contains(searchTerm)).ToList();
        }
    }
}
