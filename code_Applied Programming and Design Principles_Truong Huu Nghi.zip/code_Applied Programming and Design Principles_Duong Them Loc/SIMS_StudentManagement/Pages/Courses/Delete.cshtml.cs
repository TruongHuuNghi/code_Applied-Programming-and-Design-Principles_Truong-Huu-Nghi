using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SIMS_StudentManagement.Models;
using SIMS_StudentManagement.Services;

namespace SIMS_StudentManagement.Pages.Courses
{
    public class DeleteModel : PageModel
    {
        private readonly CourseService _courseService;

        public DeleteModel(CourseService courseService)
        {
            _courseService = courseService;
        }

        [BindProperty]
        public Course Course { get; set; }

        public IActionResult OnGet(int id)
        {
            Course = _courseService.GetCourseById(id);

            if (Course == null)
            {
                return RedirectToPage("/Courses/Index");
            }

            return Page();
        }

        public IActionResult OnPost(int id)
        {
            _courseService.DeleteCourse(id);
            return RedirectToPage("/Courses/Index");
        }
    }
}
