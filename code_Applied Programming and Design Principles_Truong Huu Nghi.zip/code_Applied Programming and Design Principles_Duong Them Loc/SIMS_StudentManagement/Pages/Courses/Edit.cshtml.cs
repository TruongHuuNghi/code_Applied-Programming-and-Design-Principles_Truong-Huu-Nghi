using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SIMS_StudentManagement.Models;
using SIMS_StudentManagement.Services;
using Microsoft.Extensions.Logging;

namespace SIMS_StudentManagement.Pages.Courses
{
    public class EditModel : PageModel
    {
        private readonly CourseService _courseService;
        private readonly ILogger<EditModel> _logger;

        public EditModel(CourseService courseService, ILogger<EditModel> logger)
        {
            _courseService = courseService;
            _logger = logger;
        }

        [BindProperty]
        public Course Course { get; set; }

        public IActionResult OnGet(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid course ID.");
            }

            Course = _courseService.GetCourseById(id);
            if (Course == null)
            {
                return NotFound();
            }
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            try
            {
                _courseService.UpdateCourse(Course);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An error occurred: {ex.Message}");
                return Page();
            }

            return RedirectToPage("Index");
        }
    }
}
