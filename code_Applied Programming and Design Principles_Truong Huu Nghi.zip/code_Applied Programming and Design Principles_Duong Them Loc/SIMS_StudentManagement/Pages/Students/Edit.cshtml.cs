using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SIMS_StudentManagement.Models;
using SIMS_StudentManagement.Services;
using Microsoft.Extensions.Logging;

namespace SIMS_StudentManagement.Pages.Students
{
    public class EditModel : PageModel
    {
        private readonly StudentService _studentService;
        private readonly ILogger<EditModel> _logger;

        public EditModel(StudentService studentService, ILogger<EditModel> logger)
        {
            _studentService = studentService;
            _logger = logger;
        }

        [BindProperty]
        public Student Student { get; set; }

        public IActionResult OnGet(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid student ID.");
            }

            Student = _studentService.GetStudentById(id);
            if (Student == null)
            {
                return NotFound();
            }
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            try
            {
                _studentService.UpdateStudent(Student);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An error occurred: {ex.Message}");
                return Page();
            }

            return RedirectToPage("Index");
        }
    }
}
