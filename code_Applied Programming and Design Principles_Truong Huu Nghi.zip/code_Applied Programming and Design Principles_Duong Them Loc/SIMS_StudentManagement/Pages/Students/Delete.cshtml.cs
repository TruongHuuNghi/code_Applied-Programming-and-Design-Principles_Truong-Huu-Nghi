using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SIMS_StudentManagement.Models;
using SIMS_StudentManagement.Services;

namespace SIMS_StudentManagement.Pages.Students
{
    public class DeleteModel : PageModel
    {
        private readonly StudentService _studentService;

        public DeleteModel(StudentService studentService)
        {
            _studentService = studentService;
        }

        [BindProperty]
        public Student Student { get; set; }

        public IActionResult OnGet(int id) 
        {
            Student = _studentService.GetStudentById(id); 
            if (Student == null)
            {
                return NotFound();
            }
            return Page();
        }

        public IActionResult OnPost()
        {
            if (Student != null)
            {
                _studentService.DeleteStudent(Student.ID); 
            }
            return RedirectToPage("Index"); 
        }
    }
}
