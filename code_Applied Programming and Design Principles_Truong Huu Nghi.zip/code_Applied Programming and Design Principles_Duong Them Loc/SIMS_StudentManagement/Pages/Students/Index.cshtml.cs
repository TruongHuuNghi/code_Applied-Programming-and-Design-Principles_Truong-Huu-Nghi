using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SIMS_StudentManagement.Models;
using SIMS_StudentManagement.Services;
using System.Collections.Generic;
using System.Linq;

namespace SIMS_StudentManagement.Pages.Students
{
    public class IndexModel : PageModel
    {
        private readonly StudentService _studentService;

        public IndexModel(StudentService studentService)
        {
            _studentService = studentService;
        }

        public List<Student> Students { get; set; }
        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }

        public void OnGet()
        {
            Students = _studentService.GetAllStudents();
            if (!string.IsNullOrEmpty(SearchTerm))
            {
                Students = Students.Where(s => s.FullName.Contains(SearchTerm) || s.MSSV.Contains(SearchTerm)).ToList();
            }
        }
    }
}
