using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SIMS_StudentManagement.Models;
using SIMS_StudentManagement.Services;

namespace SIMS_StudentManagement.Pages.Teachers
{
    public class CreateModel : PageModel
    {
        private readonly TeacherService _teacherService;

        public CreateModel(TeacherService teacherService)
        {
            _teacherService = teacherService;
        }

        [BindProperty]
        public Teacher Teacher { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _teacherService.AddTeacher(Teacher);

            return RedirectToPage("/Teachers/Index");
        }
    }
}
