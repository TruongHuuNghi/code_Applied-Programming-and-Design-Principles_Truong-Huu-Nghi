using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SIMS_StudentManagement.Models;
using SIMS_StudentManagement.Services;
using Microsoft.Extensions.Logging;

namespace SIMS_StudentManagement.Pages.Teachers
{
    public class EditModel : PageModel
    {
        private readonly TeacherService _teacherService;
        private readonly ILogger<EditModel> _logger;

        public EditModel(TeacherService teacherService, ILogger<EditModel> logger)
        {
            _teacherService = teacherService;
            _logger = logger;
        }

        [BindProperty]
        public Teacher Teacher { get; set; }

        public IActionResult OnGet(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid teacher ID.");
            }

            Teacher = _teacherService.GetTeacherById(id);
            if (Teacher == null)
            {
                return NotFound();
            }
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            try
            {
                _teacherService.UpdateTeacher(Teacher);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An error occurred: {ex.Message}");
                return Page();
            }

            return RedirectToPage("Index");
        }
    }
}
