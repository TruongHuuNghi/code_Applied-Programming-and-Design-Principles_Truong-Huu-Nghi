using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SIMS_StudentManagement.Models;
using SIMS_StudentManagement.Services;

namespace SIMS_StudentManagement.Pages.Teachers
{
    public class DeleteModel : PageModel
    {
        private readonly TeacherService _teacherService;

        public DeleteModel(TeacherService teacherService)
        {
            _teacherService = teacherService;
        }

        [BindProperty]
        public Teacher Teacher { get; set; }

        public IActionResult OnGet(int id)
        {
            Teacher = _teacherService.GetTeacherById(id);
            if (Teacher == null)
            {
                return NotFound();
            }
            return Page();
        }

        public IActionResult OnPost()
        {
            if (Teacher != null)
            {
                _teacherService.DeleteTeacher(Teacher.ID);
            }
            return RedirectToPage("Index");
        }
    }
}
