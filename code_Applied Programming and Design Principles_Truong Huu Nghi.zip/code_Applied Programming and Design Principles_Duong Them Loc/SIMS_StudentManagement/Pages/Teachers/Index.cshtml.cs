using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SIMS_StudentManagement.Models;
using SIMS_StudentManagement.Services;
using System.Collections.Generic;
using System.Linq;

namespace SIMS_StudentManagement.Pages.Teachers
{
    public class IndexModel : PageModel
    {
        private readonly TeacherService _teacherService;

        public IndexModel(TeacherService teacherService)
        {
            _teacherService = teacherService;
        }

        public List<Teacher> Teachers { get; set; }
        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }

        public void OnGet()
        {
            Teachers = _teacherService.GetAllTeachers();
            if (!string.IsNullOrEmpty(SearchTerm))
            {
                Teachers = Teachers.Where(t => t.TeacherName.Contains(SearchTerm) || t.TeacherCode.Contains(SearchTerm)).ToList();
            }
        }
    }
}
