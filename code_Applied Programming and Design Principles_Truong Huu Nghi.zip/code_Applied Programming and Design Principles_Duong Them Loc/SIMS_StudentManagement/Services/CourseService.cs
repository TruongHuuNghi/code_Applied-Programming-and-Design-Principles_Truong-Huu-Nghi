﻿using System;
using System.Collections.Generic;
using SIMS_StudentManagement.Abstractions;
using SIMS_StudentManagement.Models;

namespace SIMS_StudentManagement.Services
{
    public class CourseService
    {
        private readonly ICourse _context;

        public CourseService(ICourse context)
        {
            _context = context;
        }

        public List<Course> GetAllCourses()
        {
            return _context.ReadCourses();
        }

        public void AddCourse(Course course)
        {
            if (course == null)
                throw new ArgumentException("Invalid course data.", nameof(course));
            _context.AddCourse(course);
        }

        public Course GetCourseById(int id)
        {
            return _context.GetCourse(id);
        }

        public void UpdateCourse(Course course)
        {
            if (course == null)
                throw new ArgumentException("Invalid course data.", nameof(course));
            _context.UpdateCourse(course);
        }

        public void DeleteCourse(int id)
        {
            if (id <= 0)
                throw new ArgumentException("Invalid course ID.", nameof(id));
            _context.DeleteCourse(id);
        }
    }
}
