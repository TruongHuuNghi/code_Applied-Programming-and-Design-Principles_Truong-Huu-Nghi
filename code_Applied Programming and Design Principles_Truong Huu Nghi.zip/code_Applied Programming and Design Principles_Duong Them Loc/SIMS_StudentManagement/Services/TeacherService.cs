﻿using System;
using System.Collections.Generic;
using SIMS_StudentManagement.Abstractions;
using SIMS_StudentManagement.Models;

namespace SIMS_StudentManagement.Services
{
    public class TeacherService
    {
        private readonly ITeacher _context;

        public TeacherService(ITeacher context)
        {
            _context = context;
        }

        public List<Teacher> GetAllTeachers()
        {
            return _context.ReadTeachers();
        }

        public void AddTeacher(Teacher teacher)
        {
            if (teacher == null)
                throw new ArgumentException("Invalid teacher data.", nameof(teacher));
            _context.AddTeacher(teacher);
        }

        public Teacher GetTeacherById(int id)
        {
            return _context.GetTeacher(id);
        }

        public void UpdateTeacher(Teacher teacher)
        {
            if (teacher == null)
                throw new ArgumentException("Invalid teacher data.", nameof(teacher));
            _context.UpdateTeacher(teacher);
        }

        public void DeleteTeacher(int id)
        {
            if (id <= 0)
                throw new ArgumentException("Invalid teacher ID.", nameof(id));
            _context.DeleteTeacher(id);
        }
    }
}
