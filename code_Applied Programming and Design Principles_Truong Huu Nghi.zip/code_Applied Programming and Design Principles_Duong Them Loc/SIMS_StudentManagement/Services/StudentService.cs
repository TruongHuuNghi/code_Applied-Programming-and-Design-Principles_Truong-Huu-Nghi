﻿using System;
using System.Collections.Generic;
using SIMS_StudentManagement.Abstractions;
using SIMS_StudentManagement.Models;

namespace SIMS_StudentManagement.Services
{
    public class StudentService
    {
        private readonly IStudent _context;

        public StudentService(IStudent context)
        {
            _context = context;
        }

        public List<Student> GetAllStudents()
        {
            return _context.ReadStudents();
        }

        public void AddStudent(Student student)
        {
            if (student == null)
                throw new ArgumentException("Invalid student data.", nameof(student));
            _context.AddStudent(student);
        }

        public Student GetStudentById(int id)
        {
            return _context.GetStudent(id);
        }

        public void UpdateStudent(Student student)
        {
            if (student == null)
                throw new ArgumentException("Invalid student data.", nameof(student));
            _context.UpdateStudent(student);
        }

        public void DeleteStudent(int id)
        {
            if (id <= 0)
                throw new ArgumentException("Invalid student ID.", nameof(id));
            _context.DeleteStudent(id);
        }
    }
}
