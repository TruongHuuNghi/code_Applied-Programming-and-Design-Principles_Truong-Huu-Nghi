﻿using SIMS_StudentManagement.Abstractions;
using SIMS_StudentManagement.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SIMS_StudentManagement.DataContexts
{
    public class StudentContextCSV : IStudent
    {
        private readonly string filePath;
        private static int nextId = 1;

        public StudentContextCSV(string path)
        {
            filePath = path;
            LoadNextId();
        }

        private void LoadNextId()
        {
            if (File.Exists(filePath))
            {
                var students = ReadStudents();
                if (students.Count > 0)
                {
                    nextId = students.Max(s => s.ID) + 1;
                }
            }
        }

        public List<Student> ReadStudents()
        {
            if (!File.Exists(filePath)) return new List<Student>();

            var students = new List<Student>();
            using (var reader = new StreamReader(filePath))
            {
                string line;
                bool isFirstLine = true;

                while ((line = reader.ReadLine()) != null)
                {
                    if (isFirstLine)
                    {
                        isFirstLine = false;
                        continue; 
                    }

                    var parts = line.Split(',');
                    if (parts.Length == 6) 
                    {
                        try
                        {
                            students.Add(new Student
                            {
                                ID = int.Parse(parts[0]),
                                MSSV = parts[1],
                                FullName = parts[2],
                                DateOfBirth = DateTime.Parse(parts[3]),
                                Address = parts[4],
                                PhoneNumber = parts[5]
                            });
                        }
                        catch (FormatException ex)
                        {
                            Console.WriteLine($"Error parsing line: {line}. Exception: {ex.Message}");
                        }
                    }
                }
            }
            return students;
        }

        public void WriteStudents(List<Student> students)
        {
            using (var writer = new StreamWriter(filePath))
            {
                writer.WriteLine("ID,MSSV,FullName,DateOfBirth,Address,PhoneNumber");

                foreach (var student in students)
                {
                    writer.WriteLine($"{student.ID},{student.MSSV},{student.FullName}," +
                        $"{student.DateOfBirth},{student.Address},{student.PhoneNumber}");
                }

                if (students.Count == 0)
                {
                    nextId = 1;
                }
            }
        }

        public void AddStudent(Student student)
        {
            student.ID = nextId++;
            var students = ReadStudents();
            students.Add(student);
            WriteStudents(students);
        }

        public void DeleteStudent(int id)
        {
            var students = ReadStudents();
            var studentToRemove = students.FirstOrDefault(s => s.ID == id);
            if (studentToRemove != null)
            {
                students.Remove(studentToRemove);
                WriteStudents(students);
                if (students.Count == 0)
                {
                    nextId = 1;
                }
            }
        }

        public Student GetStudent(int id)
        {
            return ReadStudents().FirstOrDefault(s => s.ID == id);
        }

        public void UpdateStudent(Student student)
        {
            var students = ReadStudents();
            var existingStudent = students.FirstOrDefault(s => s.ID == student.ID);
            if (existingStudent != null)
            {
                existingStudent.MSSV = student.MSSV;
                existingStudent.FullName = student.FullName;
                existingStudent.DateOfBirth = student.DateOfBirth;
                existingStudent.Address = student.Address;
                existingStudent.PhoneNumber = student.PhoneNumber;
                WriteStudents(students);
            }
        }
    }
}
