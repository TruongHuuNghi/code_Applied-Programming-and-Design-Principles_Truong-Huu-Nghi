﻿using SIMS_StudentManagement.Abstractions;
using SIMS_StudentManagement.Models;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace SIMS_StudentManagement.DataContexts
{
    public class CourseContextCSV : ICourse
    {
        private readonly string filePath;
        private static int nextId = 1;

        public CourseContextCSV(string path)
        {
            filePath = path;
            LoadNextId();
        }

        private void LoadNextId()
        {
            if (File.Exists(filePath))
            {
                var courses = ReadCourses();
                if (courses.Count > 0)
                {
                    nextId = courses.Max(c => c.ID) + 1;
                }
            }
        }

        public List<Course> ReadCourses()
        {
            if (!File.Exists(filePath)) return new List<Course>();

            var courses = new List<Course>();
            using (var reader = new StreamReader(filePath))
            {
                string line;
                bool isFirstLine = true;

                while ((line = reader.ReadLine()) != null)
                {
                    if (isFirstLine)
                    {
                        isFirstLine = false;
                        continue; 
                    }

                    var parts = line.Split(',');
                    if (parts.Length == 7)
                    {
                        try
                        {
                            courses.Add(new Course
                            {
                                ID = int.Parse(parts[0]),
                                CourseCode = parts[1],
                                CourseName = parts[2],
                                Description = parts[3],
                                Credits = int.Parse(parts[4]),
                                Instructor = parts[5],
                                Classroom = parts[6]
                            });
                        }
                        catch (FormatException ex)
                        {
                            Console.WriteLine($"Error parsing line: {line}. Exception: {ex.Message}");
                        }
                    }
                }
            }
            return courses;
        }

        public void WriteCourses(List<Course> courses)
        {
            using (var writer = new StreamWriter(filePath))
            {
                writer.WriteLine("ID,CourseCode,CourseName,Description,Credits,Instructor,Classroom");

                foreach (var course in courses)
                {
                    writer.WriteLine($"{course.ID},{course.CourseCode},{course.CourseName},{course.Description}," +
                        $"{course.Credits},{course.Instructor},{course.Classroom}");
                }

                if (courses.Count == 0)
                {
                    nextId = 1;
                }
            }
        }

        public void AddCourse(Course course)
        {
            course.ID = nextId++;
            var courses = ReadCourses();
            courses.Add(course);
            WriteCourses(courses);
        }

        public void DeleteCourse(int id)
        {
            var courses = ReadCourses();
            var courseToRemove = courses.FirstOrDefault(c => c.ID == id);
            if (courseToRemove != null)
            {
                courses.Remove(courseToRemove);
                WriteCourses(courses);
                if (courses.Count == 0)
                {
                    nextId = 1;
                }
            }
        }

        public Course GetCourse(int id)
        {
            return ReadCourses().FirstOrDefault(c => c.ID == id);
        }

        public void UpdateCourse(Course course)
        {
            var courses = ReadCourses();
            var existingCourse = courses.FirstOrDefault(c => c.ID == course.ID);
            if (existingCourse != null)
            {
                existingCourse.CourseCode = course.CourseCode;
                existingCourse.CourseName = course.CourseName;
                existingCourse.Description = course.Description;
                existingCourse.Credits = course.Credits;
                existingCourse.Instructor = course.Instructor;
                existingCourse.Classroom = course.Classroom;
                WriteCourses(courses);
            }
        }
    }
}
