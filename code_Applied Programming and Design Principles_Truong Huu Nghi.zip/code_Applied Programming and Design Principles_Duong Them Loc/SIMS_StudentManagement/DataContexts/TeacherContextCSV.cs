﻿using SIMS_StudentManagement.Abstractions;
using SIMS_StudentManagement.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SIMS_StudentManagement.DataContexts
{
    public class TeacherContextCSV : ITeacher
    {
        private readonly string filePath;
        private static int nextId = 1;

        public TeacherContextCSV(string path)
        {
            filePath = path;
            LoadNextId();
        }

        private void LoadNextId()
        {
            if (File.Exists(filePath))
            {
                var teachers = ReadTeachers();
                if (teachers.Count > 0)
                {
                    nextId = teachers.Max(t => t.ID) + 1;
                }
            }
        }

        public List<Teacher> ReadTeachers()
        {
            if (!File.Exists(filePath)) return new List<Teacher>();

            var teachers = new List<Teacher>();
            using (var reader = new StreamReader(filePath))
            {
                string line;
                bool isFirstLine = true;

                while ((line = reader.ReadLine()) != null)
                {
                    if (isFirstLine)
                    {
                        isFirstLine = false;
                        continue;
                    }

                    var parts = line.Split(',');
                    if (parts.Length == 9)
                    {
                        try
                        {
                            teachers.Add(new Teacher
                            {
                                ID = int.Parse(parts[0]),
                                TeacherCode = parts[1],
                                TeacherName = parts[2],
                                DateOfBirth = DateTime.Parse(parts[3]),
                                Address = parts[4],
                                Phone = parts[5],
                                Email = parts[6],
                                Major = parts[7],
                                Qualification = parts[8]
                            });
                        }
                        catch (FormatException ex)
                        {
                            Console.WriteLine($"Error parsing line: {line}. Exception: {ex.Message}");
                        }
                    }
                }
            }
            return teachers;
        }

        public void WriteTeachers(List<Teacher> teachers)
        {
            using (var writer = new StreamWriter(filePath))
            {
                writer.WriteLine("ID,TeacherCode,TeacherName,DateOfBirth,Address,Phone,Email,Major,Qualification");

                foreach (var teacher in teachers)
                {
                    writer.WriteLine($"{teacher.ID},{teacher.TeacherCode},{teacher.TeacherName},{teacher.DateOfBirth}," +
                        $"{teacher.Address},{teacher.Phone},{teacher.Email},{teacher.Major},{teacher.Qualification}");
                }

                if (teachers.Count == 0)
                {
                    nextId = 1;
                }
            }
        }

        public void AddTeacher(Teacher teacher)
        {
            teacher.ID = nextId++;
            var teachers = ReadTeachers();
            teachers.Add(teacher);
            WriteTeachers(teachers);
        }

        public void DeleteTeacher(int id)
        {
            var teachers = ReadTeachers();
            var teacherToRemove = teachers.FirstOrDefault(t => t.ID == id);
            if (teacherToRemove != null)
            {
                teachers.Remove(teacherToRemove);
                WriteTeachers(teachers);
                if (teachers.Count == 0)
                {
                    nextId = 1;
                }
            }
        }

        public Teacher GetTeacher(int id)
        {
            return ReadTeachers().FirstOrDefault(t => t.ID == id);
        }

        public void UpdateTeacher(Teacher teacher)
        {
            var teachers = ReadTeachers();
            var existingTeacher = teachers.FirstOrDefault(t => t.ID == teacher.ID);
            if (existingTeacher != null)
            {
                existingTeacher.TeacherCode = teacher.TeacherCode;
                existingTeacher.TeacherName = teacher.TeacherName;
                existingTeacher.DateOfBirth = teacher.DateOfBirth;
                existingTeacher.Address = teacher.Address;
                existingTeacher.Phone = teacher.Phone;
                existingTeacher.Email = teacher.Email;
                existingTeacher.Major = teacher.Major;
                existingTeacher.Qualification = teacher.Qualification;
                WriteTeachers(teachers);
            }
        }
    }
}
