﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SIMS_StudentManagement.Abstractions;
using SIMS_StudentManagement.DataContexts;
using SIMS_StudentManagement.Services;

public class Startup
{
    public void ConfigureServices(IServiceCollection services)
    {
        services.AddRazorPages();

        // Register Student services
        services.AddSingleton<IStudent>(new StudentContextCSV("Data_CSV/Students.csv"));
        services.AddTransient<StudentService>();

        // Register Teacher services
        services.AddSingleton<ITeacher>(new TeacherContextCSV("Data_CSV/Teachers.csv"));
        services.AddTransient<TeacherService>();

        services.AddSingleton<ICourse>(new CourseContextCSV("Data_CSV/Courses.csv"));
        services.AddTransient<CourseService>();
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }
        else
        {
            app.UseExceptionHandler("/Error");
            app.UseHsts();
        }

        app.UseHttpsRedirection();
        app.UseStaticFiles();

        app.UseRouting();

        app.UseAuthorization();

        app.UseEndpoints(endpoints =>
        {
            endpoints.MapRazorPages();
        });
    }
}